﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Management;

/*===================================================================================================
 * Main program
 *===================================================================================================*/


namespace ThaiIdReader
{
    public partial class main : Form
    {
        const int LengthBuffer = 255;

        int LoopRec = 0;

        public CultureInfo enUsCulture = CultureInfo.GetCultureInfo("en-US");

        public string TextCom = "";
        public string TextGPS = "";
        public string TextID = "";
        public string TextSend = "";
        public bool FlagGPS = false;
        public bool FLAG_UPDATE = false;

        public string location = "";
        public string filename = "";
        public string stationName = "";
        public string stationIpAddress = "";
        public Thread threadSamplingGPS = null;
        public string Comport = "";
        public string WebserviceLink = "";

        public byte[] recieve = new byte[256];
        public byte[] DataID = new byte[256];
        public byte[] DataGPS = new byte[256];
        public byte[] BuffComPort = new byte[10000];
        public string[] DataCom = new string[9];
        public string[] DataThai = new string[9];
        public string BuffCom = "";

        public int buffer = 0;
        public int Length = 0;
        public int BuffLength = 0;

        public bool FlagEnd = false;
        public bool FlagSum = false;
        public byte CheckSum = 0x00;
        public byte DataSum = 0x00;
        public int LengthGPS = 0;
        public int LengthSum = 0;
        public int TimeOut;



        delegate void myDelegateOne(string data);
        myDelegateOne myUpdateBoxThaiID;
        myDelegateOne myUpdateBoxSex;
        myDelegateOne myUpdateBoxNameThai;
        myDelegateOne myUpdateBoxNameEnglish;
        myDelegateOne myUpdateBoxDateOfBirth;
        myDelegateOne myUpdateBoxAddress;
        myDelegateOne myUpdateBoxIssueDate;
        myDelegateOne myUpdateBoxIssuePlace;
        myDelegateOne myUpdateBoxNumber;

        /*===================================================================================================
         * Main program
         *===================================================================================================*/
        public main()
        {
            InitializeComponent();
            myUpdateBoxThaiID = new myDelegateOne(WriteBoxThaiID);
            myUpdateBoxSex = new myDelegateOne(WriteBoxSex);
            myUpdateBoxNameThai = new myDelegateOne(WriteBoxNameThai);
            myUpdateBoxNameEnglish = new myDelegateOne(WriteBoxNameEnglish);
            myUpdateBoxDateOfBirth = new myDelegateOne(WriteBoxDateOfBirth);
            myUpdateBoxAddress = new myDelegateOne(WriteBoxAddress);
            myUpdateBoxIssueDate = new myDelegateOne(WriteBoxIssueDate);
            myUpdateBoxIssuePlace = new myDelegateOne(WriteBoxIssuePlace);
            myUpdateBoxNumber = new myDelegateOne(WriteBoxNumber);

            comboCom.Items.AddRange(System.IO.Ports.SerialPort.GetPortNames());
        }
        /*===================================================================================================
         * Main Close Program
         *===================================================================================================*/
        private void Main_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.Close();
            }
        }

        /*===================================================================================================
         * Convrt Byte to Image
         *===================================================================================================*/
        private System.Drawing.Image CreateImage(byte[] image_data)
        {
            return System.Drawing.Image.FromStream(new System.IO.MemoryStream(image_data));
        }

        /*===================================================================================================
         * Comport Interrupt for Recieve Data form Radio
         *===================================================================================================*/
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                int Len = serialPort1.BytesToRead;
                TimeOut = 1;
                if (Len >= 10000)
                {
                    Len = 0;
                }
                if (BuffLength >= 10000)              // Check length data for limit  
                {
                    BuffLength = 0;                 // Initial Buffer length 
                }
                serialPort1.Read(BuffComPort, BuffLength, Len);
                BuffLength += Len;
                if (BuffLength >= 1)
                {

                    if (BuffComPort[BuffLength - 1] == '\r' && LoopRec < 9)
                    {

                        BuffCom = Encoding.GetEncoding(0x36a).GetString(BuffComPort, 0, BuffLength);
                        BuffLength = 0;
                        serialPort1.DiscardInBuffer();

                        if (BuffCom == "REMOVE\r")
                        {
                            LoopRec = 0;
                            this.Invoke(myUpdateBoxThaiID, "");
                            this.Invoke(myUpdateBoxSex, "");
                            this.Invoke(myUpdateBoxNameThai, "");
                            this.Invoke(myUpdateBoxNameEnglish, "");
                            this.Invoke(myUpdateBoxDateOfBirth, "");
                            this.Invoke(myUpdateBoxAddress, "");
                            this.Invoke(myUpdateBoxIssueDate, "");
                            this.Invoke(myUpdateBoxIssuePlace, "");
                            this.Invoke(myUpdateBoxNumber, "");
                            pictureBoxPhoto.Image = null;
                        }
                        else
                        {
                            DataCom[LoopRec] = BuffCom;
                            LoopRec++;
                        }
                    }
                    else if (BuffComPort[BuffLength - 1] == '\r' && BuffLength >= 5120 && LoopRec == 9)
                    {
                        this.Invoke(myUpdateBoxThaiID, DataCom[0]);
                        this.Invoke(myUpdateBoxSex, DataCom[1]);
                        this.Invoke(myUpdateBoxNameThai, DataCom[2]);
                        this.Invoke(myUpdateBoxNameEnglish, DataCom[3]);
                        this.Invoke(myUpdateBoxDateOfBirth, DataCom[4]);
                        this.Invoke(myUpdateBoxAddress, DataCom[5]);
                        this.Invoke(myUpdateBoxIssueDate, DataCom[6]);
                        this.Invoke(myUpdateBoxIssuePlace, DataCom[7]);
                        this.Invoke(myUpdateBoxNumber, DataCom[8]);

                        MemoryStream picture = new MemoryStream(BuffComPort);
                        pictureBoxPhoto.Image = Image.FromStream(picture);
                        pictureBoxPhoto.SizeMode = PictureBoxSizeMode.StretchImage;

                        serialPort1.DiscardInBuffer();
                        BuffLength = 0;
                        LoopRec = 0;
                    }
                }
            }
        }

        /*===================================================================================================
         * Write text box Thai ID 
         *===================================================================================================*/
        private void WriteBoxThaiID(string msg)
        {
            textBoxThaiNationID.Text = msg;
        }
        /*===================================================================================================
         * Write text Sex 
         *===================================================================================================*/
        private void WriteBoxSex(string msg)
        {
            textBoxSex.Text = msg;
        }
        /*===================================================================================================
         * Write text box Name Thai 
         *===================================================================================================*/
        private void WriteBoxNameThai(string msg)
        {
            textBoxNameThai.Text = msg;
        }
        /*===================================================================================================
         * Write text box Name English 
         *===================================================================================================*/
        private void WriteBoxNameEnglish(string msg)
        {
            textBoxNameEnglish.Text = msg;
        }
        /*===================================================================================================
         * Write text box Name English 
         *===================================================================================================*/
        private void WriteBoxDateOfBirth(string msg)
        {
            textBoxDateOfBirth.Text = msg;
        }
        /*===================================================================================================
         * Write text box Name English 
         *===================================================================================================*/
        private void WriteBoxAddress(string msg)
        {
            textBoxAddress.Text = msg;
        }
        /*===================================================================================================
         * Write text box Name English 
         *===================================================================================================*/
        private void WriteBoxIssueDate(string msg)
        {
            textBoxIssueDate.Text = msg;
        }
        /*===================================================================================================
         * Write text box Name English 
         *===================================================================================================*/
        private void WriteBoxIssuePlace(string msg)
        {
            textBoxIssuePlace.Text = msg;
        }
        /*===================================================================================================
         * Write text box Name English 
         *===================================================================================================*/
        private void WriteBoxNumber(string msg)
        {
            textBoxNumber.Text = msg;
        }

        /*===================================================================================================
         * Interrupt Timer 10 ms 
         *===================================================================================================*/
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (TimeOut != 0)
            {
                TimeOut++;
                if (TimeOut >= 5)
                {
                    if (serialPort1.IsOpen)
                    {
                        BuffLength = 0;
                        TimeOut = 0;
                        LoopRec = 0;
                    }
                }
            }
        }
//*===================================================================================================
//* Connect Disconnect Function 
//*===================================================================================================
        private void buttonConnect_Click(object sender, EventArgs e)
        {

            try
            {
                LoopRec = 0;
                this.Invoke(myUpdateBoxThaiID, "");
                this.Invoke(myUpdateBoxSex, "");
                this.Invoke(myUpdateBoxNameThai, "");
                this.Invoke(myUpdateBoxNameEnglish, "");
                this.Invoke(myUpdateBoxDateOfBirth, "");
                this.Invoke(myUpdateBoxAddress, "");
                this.Invoke(myUpdateBoxIssueDate, "");
                this.Invoke(myUpdateBoxIssuePlace, "");
                this.Invoke(myUpdateBoxNumber, "");
                pictureBoxPhoto.Image = null;

                if (!serialPort1.IsOpen)
                {
                    serialPort1.PortName = comboCom.Text;
                    serialPort1.Open();
                    buttonConnect.Text = "DISCONNECT";
                    serialPort1.DiscardInBuffer();
                }
                else
                {
                    serialPort1.Close();
                    buttonConnect.Text = "CONNECT";
                }
            }
            catch
            {
                MessageBox.Show("Please check Com Port in your system.", "ERROR!");
            }

        }

       
        /*===================================================================================================
         * End Program 
         *===================================================================================================*/
    }
}

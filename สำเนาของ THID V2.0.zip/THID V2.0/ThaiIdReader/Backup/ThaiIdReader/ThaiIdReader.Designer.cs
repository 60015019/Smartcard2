﻿namespace ThaiIdReader
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.buttonConnect = new System.Windows.Forms.Button();
            this.comboCom = new System.Windows.Forms.ComboBox();
            this.textBoxSex = new System.Windows.Forms.TextBox();
            this.labelSex = new System.Windows.Forms.Label();
            this.textBoxNumber = new System.Windows.Forms.TextBox();
            this.labelNumber = new System.Windows.Forms.Label();
            this.textBoxIssuePlace = new System.Windows.Forms.TextBox();
            this.labelIssueDate = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.labelIssuePlace = new System.Windows.Forms.Label();
            this.textBoxIssueDate = new System.Windows.Forms.TextBox();
            this.textBoxAddress = new System.Windows.Forms.TextBox();
            this.labelAddress = new System.Windows.Forms.Label();
            this.textBoxDateOfBirth = new System.Windows.Forms.TextBox();
            this.labelNameThai = new System.Windows.Forms.Label();
            this.textBoxThaiNationID = new System.Windows.Forms.TextBox();
            this.labelThaiNationID = new System.Windows.Forms.Label();
            this.pictureBoxPhoto = new System.Windows.Forms.PictureBox();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.labelDateOfDate = new System.Windows.Forms.Label();
            this.textBoxNameEnglish = new System.Windows.Forms.TextBox();
            this.labelNameEnglish = new System.Windows.Forms.Label();
            this.textBoxNameThai = new System.Windows.Forms.TextBox();
            this.labelNotice = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPhoto)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonConnect
            // 
            this.buttonConnect.Location = new System.Drawing.Point(550, 219);
            this.buttonConnect.Name = "buttonConnect";
            this.buttonConnect.Size = new System.Drawing.Size(90, 49);
            this.buttonConnect.TabIndex = 60;
            this.buttonConnect.Text = "CONNECT";
            this.buttonConnect.UseVisualStyleBackColor = true;
            this.buttonConnect.Click += new System.EventHandler(this.buttonConnect_Click);
            // 
            // comboCom
            // 
            this.comboCom.FormattingEnabled = true;
            this.comboCom.Location = new System.Drawing.Point(549, 186);
            this.comboCom.Name = "comboCom";
            this.comboCom.Size = new System.Drawing.Size(90, 21);
            this.comboCom.TabIndex = 59;
            this.comboCom.Text = "--Select COM--";
            // 
            // textBoxSex
            // 
            this.textBoxSex.Location = new System.Drawing.Point(130, 69);
            this.textBoxSex.Name = "textBoxSex";
            this.textBoxSex.Size = new System.Drawing.Size(384, 20);
            this.textBoxSex.TabIndex = 58;
            // 
            // labelSex
            // 
            this.labelSex.AutoSize = true;
            this.labelSex.Location = new System.Drawing.Point(17, 72);
            this.labelSex.Name = "labelSex";
            this.labelSex.Size = new System.Drawing.Size(25, 13);
            this.labelSex.TabIndex = 57;
            this.labelSex.Text = "Sex";
            // 
            // textBoxNumber
            // 
            this.textBoxNumber.Location = new System.Drawing.Point(130, 252);
            this.textBoxNumber.Name = "textBoxNumber";
            this.textBoxNumber.Size = new System.Drawing.Size(384, 20);
            this.textBoxNumber.TabIndex = 56;
            // 
            // labelNumber
            // 
            this.labelNumber.AutoSize = true;
            this.labelNumber.Location = new System.Drawing.Point(17, 255);
            this.labelNumber.Name = "labelNumber";
            this.labelNumber.Size = new System.Drawing.Size(44, 13);
            this.labelNumber.TabIndex = 55;
            this.labelNumber.Text = "Number";
            // 
            // textBoxIssuePlace
            // 
            this.textBoxIssuePlace.Location = new System.Drawing.Point(130, 225);
            this.textBoxIssuePlace.Name = "textBoxIssuePlace";
            this.textBoxIssuePlace.Size = new System.Drawing.Size(384, 20);
            this.textBoxIssuePlace.TabIndex = 54;
            // 
            // labelIssueDate
            // 
            this.labelIssueDate.AutoSize = true;
            this.labelIssueDate.Location = new System.Drawing.Point(17, 202);
            this.labelIssueDate.Name = "labelIssueDate";
            this.labelIssueDate.Size = new System.Drawing.Size(70, 13);
            this.labelIssueDate.TabIndex = 51;
            this.labelIssueDate.Text = "Issue of Date";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // labelIssuePlace
            // 
            this.labelIssuePlace.AutoSize = true;
            this.labelIssuePlace.Location = new System.Drawing.Point(17, 228);
            this.labelIssuePlace.Name = "labelIssuePlace";
            this.labelIssuePlace.Size = new System.Drawing.Size(74, 13);
            this.labelIssuePlace.TabIndex = 53;
            this.labelIssuePlace.Text = "Issue of Place";
            // 
            // textBoxIssueDate
            // 
            this.textBoxIssueDate.Location = new System.Drawing.Point(130, 199);
            this.textBoxIssueDate.Name = "textBoxIssueDate";
            this.textBoxIssueDate.Size = new System.Drawing.Size(384, 20);
            this.textBoxIssueDate.TabIndex = 52;
            // 
            // textBoxAddress
            // 
            this.textBoxAddress.Location = new System.Drawing.Point(130, 173);
            this.textBoxAddress.Name = "textBoxAddress";
            this.textBoxAddress.Size = new System.Drawing.Size(384, 20);
            this.textBoxAddress.TabIndex = 50;
            // 
            // labelAddress
            // 
            this.labelAddress.AutoSize = true;
            this.labelAddress.Location = new System.Drawing.Point(17, 176);
            this.labelAddress.Name = "labelAddress";
            this.labelAddress.Size = new System.Drawing.Size(27, 13);
            this.labelAddress.TabIndex = 49;
            this.labelAddress.Text = "ที่อยู่";
            // 
            // textBoxDateOfBirth
            // 
            this.textBoxDateOfBirth.Location = new System.Drawing.Point(130, 147);
            this.textBoxDateOfBirth.Name = "textBoxDateOfBirth";
            this.textBoxDateOfBirth.Size = new System.Drawing.Size(384, 20);
            this.textBoxDateOfBirth.TabIndex = 48;
            // 
            // labelNameThai
            // 
            this.labelNameThai.AutoSize = true;
            this.labelNameThai.Location = new System.Drawing.Point(17, 98);
            this.labelNameThai.Name = "labelNameThai";
            this.labelNameThai.Size = new System.Drawing.Size(64, 13);
            this.labelNameThai.TabIndex = 43;
            this.labelNameThai.Text = "ชื่อ/นามสกุล";
            // 
            // textBoxThaiNationID
            // 
            this.textBoxThaiNationID.Location = new System.Drawing.Point(130, 43);
            this.textBoxThaiNationID.Name = "textBoxThaiNationID";
            this.textBoxThaiNationID.Size = new System.Drawing.Size(384, 20);
            this.textBoxThaiNationID.TabIndex = 42;
            // 
            // labelThaiNationID
            // 
            this.labelThaiNationID.AutoSize = true;
            this.labelThaiNationID.Location = new System.Drawing.Point(17, 46);
            this.labelThaiNationID.Name = "labelThaiNationID";
            this.labelThaiNationID.Size = new System.Drawing.Size(107, 13);
            this.labelThaiNationID.TabIndex = 41;
            this.labelThaiNationID.Text = "Identification Number";
            // 
            // pictureBoxPhoto
            // 
            this.pictureBoxPhoto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxPhoto.ErrorImage = null;
            this.pictureBoxPhoto.Location = new System.Drawing.Point(549, 43);
            this.pictureBoxPhoto.Name = "pictureBoxPhoto";
            this.pictureBoxPhoto.Size = new System.Drawing.Size(91, 112);
            this.pictureBoxPhoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxPhoto.TabIndex = 40;
            this.pictureBoxPhoto.TabStop = false;
            // 
            // serialPort1
            // 
            this.serialPort1.BaudRate = 115200;
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // labelDateOfDate
            // 
            this.labelDateOfDate.AutoSize = true;
            this.labelDateOfDate.Location = new System.Drawing.Point(15, 150);
            this.labelDateOfDate.Name = "labelDateOfDate";
            this.labelDateOfDate.Size = new System.Drawing.Size(66, 13);
            this.labelDateOfDate.TabIndex = 47;
            this.labelDateOfDate.Text = "Date of Birth";
            // 
            // textBoxNameEnglish
            // 
            this.textBoxNameEnglish.Location = new System.Drawing.Point(130, 121);
            this.textBoxNameEnglish.Name = "textBoxNameEnglish";
            this.textBoxNameEnglish.Size = new System.Drawing.Size(384, 20);
            this.textBoxNameEnglish.TabIndex = 46;
            // 
            // labelNameEnglish
            // 
            this.labelNameEnglish.AutoSize = true;
            this.labelNameEnglish.Location = new System.Drawing.Point(17, 124);
            this.labelNameEnglish.Name = "labelNameEnglish";
            this.labelNameEnglish.Size = new System.Drawing.Size(82, 13);
            this.labelNameEnglish.TabIndex = 45;
            this.labelNameEnglish.Text = "Name/Surname";
            // 
            // textBoxNameThai
            // 
            this.textBoxNameThai.Location = new System.Drawing.Point(130, 95);
            this.textBoxNameThai.Name = "textBoxNameThai";
            this.textBoxNameThai.Size = new System.Drawing.Size(384, 20);
            this.textBoxNameThai.TabIndex = 44;
            // 
            // labelNotice
            // 
            this.labelNotice.AutoSize = true;
            this.labelNotice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.labelNotice.ForeColor = System.Drawing.Color.Red;
            this.labelNotice.Location = new System.Drawing.Point(16, 9);
            this.labelNotice.Name = "labelNotice";
            this.labelNotice.Size = new System.Drawing.Size(645, 20);
            this.labelNotice.TabIndex = 61;
            this.labelNotice.Text = "คำเตือน : ต้องโยก Dip Switch ไปที่ตำแหน่ง ON ทั้ง 10 ช่อง ก่อนเสียบบัตรประจำตัวปร" +
                "ะชาชน";
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(667, 285);
            this.Controls.Add(this.labelNotice);
            this.Controls.Add(this.buttonConnect);
            this.Controls.Add(this.comboCom);
            this.Controls.Add(this.textBoxSex);
            this.Controls.Add(this.labelSex);
            this.Controls.Add(this.textBoxNumber);
            this.Controls.Add(this.labelNumber);
            this.Controls.Add(this.textBoxIssuePlace);
            this.Controls.Add(this.labelIssueDate);
            this.Controls.Add(this.labelIssuePlace);
            this.Controls.Add(this.textBoxIssueDate);
            this.Controls.Add(this.textBoxAddress);
            this.Controls.Add(this.labelAddress);
            this.Controls.Add(this.textBoxDateOfBirth);
            this.Controls.Add(this.labelNameThai);
            this.Controls.Add(this.textBoxThaiNationID);
            this.Controls.Add(this.labelThaiNationID);
            this.Controls.Add(this.pictureBoxPhoto);
            this.Controls.Add(this.labelDateOfDate);
            this.Controls.Add(this.textBoxNameEnglish);
            this.Controls.Add(this.labelNameEnglish);
            this.Controls.Add(this.textBoxNameThai);
            this.MaximizeBox = false;
            this.Name = "main";
            this.Text = "Thai Nation ID Reader (ADISAK TEL:083 0066646)";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPhoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonConnect;
        private System.Windows.Forms.ComboBox comboCom;
        private System.Windows.Forms.TextBox textBoxSex;
        private System.Windows.Forms.Label labelSex;
        private System.Windows.Forms.TextBox textBoxNumber;
        private System.Windows.Forms.Label labelNumber;
        private System.Windows.Forms.TextBox textBoxIssuePlace;
        private System.Windows.Forms.Label labelIssueDate;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label labelIssuePlace;
        private System.Windows.Forms.TextBox textBoxIssueDate;
        private System.Windows.Forms.TextBox textBoxAddress;
        private System.Windows.Forms.Label labelAddress;
        private System.Windows.Forms.TextBox textBoxDateOfBirth;
        private System.Windows.Forms.Label labelNameThai;
        private System.Windows.Forms.TextBox textBoxThaiNationID;
        private System.Windows.Forms.Label labelThaiNationID;
        private System.Windows.Forms.PictureBox pictureBoxPhoto;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Label labelDateOfDate;
        private System.Windows.Forms.TextBox textBoxNameEnglish;
        private System.Windows.Forms.Label labelNameEnglish;
        private System.Windows.Forms.TextBox textBoxNameThai;
        private System.Windows.Forms.Label labelNotice;
    }
}

